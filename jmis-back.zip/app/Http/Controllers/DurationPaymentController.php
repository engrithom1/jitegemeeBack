<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DurationPaymentController extends Controller
{
    //
}
